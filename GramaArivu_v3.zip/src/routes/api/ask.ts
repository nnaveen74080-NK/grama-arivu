import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/ask")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { answer, speech, transcribe, AiError } = await import("@/lib/ai.server");
        try {
          const fd = await request.formData();
          const lang = String(fd.get("lang") ?? "ta");
          let text = String(fd.get("text") ?? "");
          const image = fd.get("image") ? String(fd.get("image")) : undefined;
          const audio = fd.get("audio");
          const history = JSON.parse(String(fd.get("history") ?? "[]"));
          let transcript: string | undefined;
          if (audio && typeof audio !== "string") {
            if (audio.size > 20_000_000) return Response.json({ error: "Voice too long" }, { status: 400 });
            transcript = await transcribe(audio, audio.name || "voice.webm");
            text = transcript;
            if (!text) return Response.json({ error: "empty_voice" }, { status: 400 });
          }
          const reply = await answer(lang, history, text, image);
          let audioUrl: string | undefined;
          try { audioUrl = await speech(reply); } catch (e) { console.error(e); }
          return Response.json({ transcript, reply, audio: audioUrl });
        } catch (e) {
          console.error(e);
          const status = e instanceof AiError ? e.status : 500;
          return Response.json({ error: e instanceof Error ? e.message : "Error" }, { status });
        }
      },
    },
  },
});
