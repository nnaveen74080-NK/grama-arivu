import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { ArrowLeft, Camera, CheckCheck, FileText, Mic, Pause, Play, RefreshCw, Send, Trash2, Upload, Bot } from "lucide-react";
import { agentDetectDoc, agentIntent, DOC_NAMES, type DocType, type Lang, type Scheme } from "@/lib/agents";
import { renderReply, SUGGESTIONS, UI, type Reply } from "@/lib/replies";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "GramaArivu — Tamil AI guide for government schemes" },
      { name: "description", content: "WhatsApp-style Tamil/Tanglish assistant that explains government schemes, eligibility and documents by text, voice and photo." },
      { property: "og:title", content: "GramaArivu — Tamil AI scheme assistant" },
      { property: "og:description", content: "Ask about any government scheme in Tamil or Tanglish, by voice or photo." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Index,
});

type Msg = {
  id: number;
  from: "me" | "bot";
  time: string;
  text?: string | undefined;
  reply?: Reply;
  audioUrl?: string | undefined;
  duration?: number;
  botVoice?: boolean; // bot voice note
  doc?: { type: DocType | null; img?: string | undefined; label: string };
  ai?: string;
  voiceSrc?: string;
};

const TEST_DOCS: DocType[] = ["ration", "income", "patta", "passbook", "community", "photo"];
const LANGS: { id: Lang; label: string }[] = [
  { id: "ta", label: "தமிழ்" },
  { id: "tl", label: "Tanglish" },
  { id: "en", label: "English" },
];

const now = () => new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
let uid = 1;

function speakable(t: string) {
  return t.replace(/[*✅⬜📋💰✔️📄🪜📷🗂️💡🎉🙏•]/gu, "").replace(/\n+/g, ". ");
}

function speak(text: string, lang: Lang, onEnd?: () => void) {
  if (typeof window === "undefined" || !window.speechSynthesis) return onEnd?.();
  window.speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(speakable(text));
  u.lang = lang === "en" ? "en-IN" : "ta-IN";
  const v = window.speechSynthesis.getVoices().find((x) => x.lang.startsWith(lang === "en" ? "en" : "ta"));
  if (v) u.voice = v;
  u.rate = 0.9;
  u.onend = () => onEnd?.();
  u.onerror = () => onEnd?.();
  window.speechSynthesis.speak(u);
}

function welcome(): Msg[] {
  return [{ id: uid++, from: "bot", time: now(), reply: { kind: "greet" } }];
}

function Index() {
  const [lang, setLang] = useState<Lang>("ta");
  const [msgs, setMsgs] = useState<Msg[]>(welcome);
  const [input, setInput] = useState("");
  const [typing, setTyping] = useState(false);
  const [have, setHave] = useState<DocType[]>([]);
  const [scheme, setScheme] = useState<Scheme | null>(null);
  const [recording, setRecording] = useState(false);
  const [recSecs, setRecSecs] = useState(0);
  const [playing, setPlaying] = useState<number | null>(null);
  const [showDocs, setShowDocs] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const recRef = useRef<{ mr: MediaRecorder; chunks: Blob[]; sr: any; transcript: string; timer: number; cancel: boolean } | null>(null);
  const langRef = useRef(lang);
  langRef.current = lang;
  const t = UI[lang];

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [msgs, typing]);

  function botRespond(reply: Reply, voice: boolean) {
    setTyping(true);
    setTimeout(() => {
      setTyping(false);
      const textMsg: Msg = { id: uid++, from: "bot", time: now(), reply };
      const out = [textMsg];
      if (voice) out.push({ id: uid++, from: "bot", time: now(), reply, botVoice: true });
      setMsgs((m) => [...m, ...out]);
      if (voice) {
        const vid = out[1]!.id;
        setPlaying(vid);
        speak(renderReply(reply, langRef.current), langRef.current, () => setPlaying((p) => (p === vid ? null : p)));
      }
    }, 900);
  }

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const msgsRef = useRef(msgs);
  msgsRef.current = msgs;

  function stopAudio() {
    window.speechSynthesis?.cancel();
    audioRef.current?.pause();
    setPlaying(null);
  }

  function playSrc(id: number, src: string) {
    stopAudio();
    const a = new Audio(src);
    audioRef.current = a;
    a.onended = () => setPlaying((p) => (p === id ? null : p));
    setPlaying(id);
    a.play().catch(() => setPlaying(null));
  }

  function history() {
    return msgsRef.current
      .filter((m) => !m.botVoice && (m.ai || m.text))
      .map((m) => ({ role: m.from === "me" ? "user" : "assistant", text: (m.ai ?? m.text)! }));
  }

  async function askAI(p: { text?: string; image?: string; audio?: Blob; userId?: number }) {
    setTyping(true);
    const fd = new FormData();
    fd.append("lang", langRef.current);
    fd.append("history", JSON.stringify(history()));
    if (p.text) fd.append("text", p.text);
    if (p.image) fd.append("image", p.image);
    if (p.audio) fd.append("audio", p.audio, "voice.webm");
    try {
      const r = await fetch("/api/ask", { method: "POST", body: fd });
      const j = await r.json();
      if (!r.ok) throw new Error(j.error === "empty_voice" ? "voice" : j.error || "error");
      if (j.transcript && p.userId) setMsgs((m) => m.map((x) => (x.id === p.userId ? { ...x, text: j.transcript } : x)));
      const out: Msg[] = [{ id: uid++, from: "bot", time: now(), ai: j.reply }];
      if (j.audio) out.push({ id: uid++, from: "bot", time: now(), ai: j.reply, botVoice: true, voiceSrc: j.audio });
      setMsgs((m) => [...m, ...out]);
      if (j.audio) playSrc(out[1]!.id, j.audio);
    } catch (e) {
      const l = langRef.current;
      const voice = e instanceof Error && e.message === "voice";
      const msg = voice
        ? l === "en" ? "I couldn't hear your voice. Please speak again a bit louder." : l === "tl" ? "Unga voice kekkala. Konjam satham-aa thirumba pesunga." : "உங்கள் குரல் கேட்கவில்லை. கொஞ்சம் சத்தமாக மீண்டும் பேசுங்கள்."
        : (l === "en" ? "Sorry, something went wrong: " : "மன்னிக்கவும், பிழை: ") + (e instanceof Error ? e.message : "");
      setMsgs((m) => [...m, { id: uid++, from: "bot", time: now(), ai: msg }]);
    } finally {
      setTyping(false);
    }
  }

  function sendText(text = input) {
    const v = text.trim();
    if (!v) return;
    setMsgs((m) => [...m, { id: uid++, from: "me", time: now(), text: v }]);
    setInput("");
    askAI({ text: v });
  }

  function sendDoc(type: DocType | null, label: string, img?: string) {
    setMsgs((m) => [...m, { id: uid++, from: "me", time: now(), doc: { type, label, img } }]);
    const nextHave = type && !have.includes(type) ? [...have, type] : have;
    setHave(nextHave);
    botRespond({ kind: "docReceived", doc: type, scheme, have: nextHave }, false);
    setShowDocs(false);
  }

  async function onFile(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0];
    e.target.value = "";
    if (!f || !f.type.startsWith("image/")) return;
    const img = await shrink(f);
    const type = agentDetectDoc(f.name);
    setMsgs((m) => [...m, { id: uid++, from: "me", time: now(), doc: { type, label: f.name, img } }]);
    if (type && !have.includes(type)) setHave([...have, type]);
    setShowDocs(false);
    askAI({ image: img, text: "இந்த ஆவணத்தை சரிபார்த்து சொல்லுங்கள்" + (scheme ? ` (scheme: ${scheme.name.en})` : "") });
  }

  async function startRec() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mr = new MediaRecorder(stream);
      const chunks: Blob[] = [];
      mr.ondataavailable = (e) => chunks.push(e.data);
      const state = { mr, chunks, sr: null as any, transcript: "", timer: 0, cancel: false };
      mr.onstop = () => {
        stream.getTracks().forEach((tr) => tr.stop());
        if (state.cancel) return;
        const blob = new Blob(chunks, { type: mr.mimeType });
        const url = URL.createObjectURL(blob);
        const secs = Math.max(1, recSecsRef.current);
        const id = uid++;
        setMsgs((m) => [...m, { id, from: "me", time: now(), audioUrl: url, duration: secs }]);
        askAI({ audio: blob, userId: id });
      };
      mr.start();
      recRef.current = state;
      setRecSecs(0);
      recSecsRef.current = 0;
      state.timer = window.setInterval(() => {
        recSecsRef.current += 1;
        setRecSecs(recSecsRef.current);
      }, 1000);
      setRecording(true);
    } catch {
      alert("Microphone permission venum / Microphone access needed");
    }
  }
  const recSecsRef = useRef(0);

  function stopRec(cancel = false) {
    const r = recRef.current;
    if (!r) return;
    r.cancel = cancel;
    clearInterval(r.timer);
    try { r.sr?.stop(); } catch {}
    r.mr.stop();
    recRef.current = null;
    setRecording(false);
  }

  function refresh() {
    stopAudio();
    setMsgs(welcome());
    setHave([]);
    setScheme(null);
    setInput("");
    setPlaying(null);
  }

  function toggleBotVoice(m: Msg) {
    if (playing === m.id) return stopAudio();
    if (m.voiceSrc) return playSrc(m.id, m.voiceSrc);
    setPlaying(m.id);
    speak(m.ai ?? renderReply(m.reply!, lang), lang, () => setPlaying((p) => (p === m.id ? null : p)));
  }

  const docsPanel = (
    <div className="flex flex-col gap-3">
      <div>
        <h3 className="font-display text-lg font-semibold">{t.docs}</h3>
        <p className="text-sm text-muted-foreground">{t.docsHint}</p>
      </div>
      <div className="grid grid-cols-2 gap-2">
        {TEST_DOCS.map((d) => (
          <button key={d} onClick={() => sendDoc(d, DOC_NAMES[d][lang])} className="rounded-lg border bg-card p-2 text-left transition hover:border-primary hover:shadow-md">
            <DocThumb type={d} lang={lang} />
            <span className="mt-1 block text-xs font-medium">{DOC_NAMES[d][lang]}</span>
          </button>
        ))}
      </div>
      <button onClick={() => fileRef.current?.click()} className="flex items-center justify-center gap-2 rounded-lg border border-dashed border-primary p-3 text-sm font-medium text-primary hover:bg-secondary">
        <Upload className="h-4 w-4" /> {t.upload}
      </button>
      <div className="mt-2 rounded-lg bg-secondary p-3 text-xs text-secondary-foreground">
        <p className="mb-1 font-semibold">{t.agents}</p>
        <p>1 · Listener & Intent</p>
        <p>2 · Scheme Matcher (local DB)</p>
        <p>3 · Compliance & Document Verifier</p>
        {scheme && <p className="mt-2 font-medium">→ {scheme.name[lang]}</p>}
      </div>
    </div>
  );

  return (
    <div className="flex min-h-screen items-center justify-center gap-6 p-0 md:p-6">
      <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={onFile} />
      <div className="flex h-screen w-full max-w-md flex-col overflow-hidden bg-card shadow-2xl md:h-[90vh] md:rounded-2xl">
        {/* Header */}
        <header className="flex items-center gap-3 bg-header px-3 py-2.5 text-header-foreground">
          <ArrowLeft className="h-5 w-5 opacity-80" />
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-turmeric font-display text-lg font-bold text-accent-foreground">கி</div>
          <div className="flex-1 leading-tight">
            <p className="font-display font-semibold">GramaArivu</p>
            <p className="text-xs opacity-80">{typing ? t.typing : t.online}</p>
          </div>
          <button aria-label="Refresh chat" onClick={refresh} className="rounded-full p-2 hover:bg-header-foreground/10">
            <RefreshCw className="h-5 w-5" />
          </button>
          <button aria-label="Documents" onClick={() => setShowDocs((s) => !s)} className="rounded-full p-2 hover:bg-header-foreground/10 lg:hidden">
            <FileText className="h-5 w-5" />
          </button>
        </header>
        {/* Language */}
        <div className="flex gap-1 bg-header px-3 pb-2">
          {LANGS.map((l) => (
            <button key={l.id} onClick={() => { stopAudio(); setLang(l.id); }}
              className={`rounded-full px-3 py-1 text-xs font-medium transition ${lang === l.id ? "bg-turmeric text-accent-foreground" : "bg-header-foreground/10 text-header-foreground"}`}>
              {l.label}
            </button>
          ))}
        </div>

        {showDocs && <div className="max-h-[55%] overflow-y-auto border-b bg-background p-3 lg:hidden">{docsPanel}</div>}

        {/* Messages */}
        <div className="chat-pattern flex-1 space-y-2 overflow-y-auto px-3 py-4">
          {msgs.map((m) => (
            <div key={m.id} className={`flex ${m.from === "me" ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-[82%] rounded-lg px-2.5 py-1.5 text-[15px] shadow-sm ${m.from === "me" ? "rounded-tr-none bg-bubble-out" : "rounded-tl-none bg-bubble-in"}`}>
                {m.doc && (
                  <div className="mb-1 w-52">
                    {m.doc.img ? <img src={m.doc.img} alt={m.doc.label} className="h-40 w-full rounded object-cover" /> : <DocThumb type={m.doc.type!} lang={lang} big />}
                    <p className="mt-1 flex items-center gap-1 text-xs text-muted-foreground"><Camera className="h-3 w-3" /> {m.doc.type ? DOC_NAMES[m.doc.type][lang] : m.doc.label}</p>
                  </div>
                )}
                {m.audioUrl && <UserVoice url={m.audioUrl} secs={m.duration ?? 1} />}
                {m.audioUrl && m.text && <p className="mt-1 text-xs italic text-muted-foreground">🎙 {t.listening}: “{m.text}”</p>}
                {m.botVoice && (m.reply || m.ai) && (
                  <button onClick={() => toggleBotVoice(m)} className="flex w-56 items-center gap-2 py-1">
                    <span className="flex h-9 w-9 items-center justify-center rounded-full bg-primary text-primary-foreground">
                      {playing === m.id ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                    </span>
                    <Waves active={playing === m.id} />
                    <Bot className="h-4 w-4 text-primary" />
                  </button>
                )}
                {!m.audioUrl && !m.botVoice && (m.text || m.reply || m.ai) && (
                  <p className="whitespace-pre-line">{m.ai ?? (m.reply ? renderReply(m.reply, lang) : m.text)}</p>
                )}
                <p className="mt-0.5 flex items-center justify-end gap-1 text-[10px] text-muted-foreground">
                  {m.time} {m.from === "me" && <CheckCheck className="h-3.5 w-3.5 text-tick" />}
                </p>
              </div>
            </div>
          ))}
          {typing && (
            <div className="flex"><div className="rounded-lg bg-bubble-in px-3 py-2 text-sm text-muted-foreground shadow-sm">● ● ●</div></div>
          )}
          <div ref={endRef} />
        </div>

        {/* Suggestions */}
        <div className="flex gap-2 overflow-x-auto bg-chat px-3 pb-2">
          {SUGGESTIONS[lang].map((s) => (
            <button key={s} onClick={() => sendText(s)} className="shrink-0 rounded-full border border-primary/40 bg-card px-3 py-1 text-xs text-primary">{s}</button>
          ))}
        </div>

        {/* Composer */}
        <div className="flex items-center gap-2 bg-chat px-2 pb-3">
          {recording ? (
            <div className="flex flex-1 items-center gap-3 rounded-full bg-card px-4 py-2.5">
              <button aria-label="Cancel" onClick={() => stopRec(true)}><Trash2 className="h-5 w-5 text-destructive" /></button>
              <span className="h-2.5 w-2.5 animate-pulse rounded-full bg-destructive" />
              <span className="text-sm">{t.rec} 0:{String(recSecs).padStart(2, "0")}</span>
            </div>
          ) : (
            <div className="flex flex-1 items-center gap-2 rounded-full bg-card px-4 py-2">
              <input value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => e.key === "Enter" && sendText()} placeholder={t.placeholder} className="flex-1 bg-transparent py-1 outline-none" />
              <button aria-label="Attach photo" onClick={() => fileRef.current?.click()}><Camera className="h-5 w-5 text-muted-foreground" /></button>
            </div>
          )}
          <button
            aria-label={input ? "Send" : recording ? "Send voice" : "Record voice"}
            onClick={() => (input ? sendText() : recording ? stopRec() : startRec())}
            className="flex h-12 w-12 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-md"
          >
            {input || recording ? <Send className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
          </button>
        </div>
      </div>

      <aside className="hidden w-80 rounded-2xl bg-card p-4 shadow-xl lg:block">{docsPanel}</aside>
    </div>
  );
}

function shrink(f: File): Promise<string> {
  return new Promise((res, rej) => {
    const img = new Image();
    img.onload = () => {
      const k = Math.min(1, 1280 / Math.max(img.width, img.height));
      const c = document.createElement("canvas");
      c.width = img.width * k;
      c.height = img.height * k;
      c.getContext("2d")!.drawImage(img, 0, 0, c.width, c.height);
      res(c.toDataURL("image/jpeg", 0.85));
    };
    img.onerror = rej;
    img.src = URL.createObjectURL(f);
  });
}

function Waves({ active }: { active: boolean }) {
  return (
    <span className="flex flex-1 items-center gap-0.5">
      {Array.from({ length: 22 }).map((_, i) => (
        <span key={i} className={`w-0.5 rounded bg-muted-foreground ${active ? "wave-bar" : ""}`} style={{ height: 6 + ((i * 7) % 14), animationDelay: `${i * 40}ms` }} />
      ))}
    </span>
  );
}

function UserVoice({ url, secs }: { url: string; secs: number }) {
  const ref = useRef<HTMLAudioElement>(null);
  const [on, setOn] = useState(false);
  return (
    <button onClick={() => { const a = ref.current!; if (on) a.pause(); else a.play(); }} className="flex w-56 items-center gap-2 py-1">
      <audio ref={ref} src={url} onPlay={() => setOn(true)} onPause={() => setOn(false)} onEnded={() => setOn(false)} />
      <span className="flex h-9 w-9 items-center justify-center rounded-full bg-primary text-primary-foreground">{on ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}</span>
      <Waves active={on} />
      <span className="text-xs text-muted-foreground">0:{String(secs).padStart(2, "0")}</span>
    </button>
  );
}

function DocThumb({ type, lang, big }: { type: DocType; lang: Lang; big?: boolean }) {
  return (
    <div className={`flex flex-col justify-between rounded border-2 border-primary/30 bg-secondary p-2 ${big ? "h-32" : "h-20"}`}>
      <div className="flex items-center gap-1">
        <span className="h-3 w-3 rounded-full bg-turmeric" />
        <span className="text-[9px] font-bold uppercase tracking-wide text-secondary-foreground">Govt of Tamil Nadu</span>
      </div>
      <p className={`font-display font-semibold text-secondary-foreground ${big ? "text-sm" : "text-[10px]"}`}>{DOC_NAMES[type][lang]}</p>
      <div className="space-y-0.5">
        <div className="h-1 w-3/4 rounded bg-primary/30" />
        <div className="h-1 w-1/2 rounded bg-primary/20" />
      </div>
    </div>
  );
}
