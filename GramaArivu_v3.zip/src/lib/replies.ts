import { DOC_NAMES, SCHEMES, type DocGuide, type DocType, type Lang, type Scheme } from "./agents";

// Bot replies are stored as structured data and rendered at view time,
// so switching language re-renders every past message instantly.
export type Reply =
  | { kind: "greet" }
  | { kind: "scheme"; scheme: Scheme; have: DocType[] }
  | { kind: "docguide"; guide: DocGuide }
  | { kind: "list" }
  | { kind: "docReceived"; doc: DocType | null; scheme: Scheme | null; have: DocType[] }
  | { kind: "verify"; scheme: Scheme | null; have: DocType[] }
  | { kind: "unknown" };

const L = (lang: Lang, ta: string, tl: string, en: string) => (lang === "ta" ? ta : lang === "tl" ? tl : en);

function checklist(lang: Lang, docs: DocType[], have: DocType[]) {
  return docs.map((d) => `${have.includes(d) ? "✅" : "⬜"} ${DOC_NAMES[d][lang]}`).join("\n");
}

export function renderReply(r: Reply, lang: Lang): string {
  switch (r.kind) {
    case "greet":
      return L(lang,
        "வணக்கம்! 🙏 நான் கிராம அறிவு. அரசுத் திட்டம், கடன், உதவித்தொகை — எதைப் பத்தியும் கேளுங்க. டைப் பண்ணலாம், வாய்ஸ் அனுப்பலாம், ஆவணப் புகைப்படம் அனுப்பலாம்.",
        "Vanakkam! 🙏 Naan GramaArivu. Govt scheme, loan, scholarship — edhai pathi venaalum kelunga. Type pannalam, voice anupalam, document photo anupalam.",
        "Hello! 🙏 I'm GramaArivu. Ask me about any government scheme, loan or subsidy — by text, voice note or document photo.");
    case "list":
      return L(lang, "இந்த திட்டங்கள் பத்தி நான் சொல்ல முடியும்:\n\n", "Indha schemes pathi naan solla mudiyum:\n\n", "I can help with these schemes:\n\n") +
        SCHEMES.map((s, i) => `${i + 1}. ${s.name[lang]}`).join("\n") +
        L(lang, "\n\nஏதாவது ஒரு பெயரை சொல்லுங்க.", "\n\nEdhavadhu oru per sollunga.", "\n\nTell me any one name.");
    case "scheme": {
      const s = r.scheme;
      return [
        `📋 *${s.name[lang]}*`,
        `\n💰 ${L(lang, "பலன்", "Benefit", "Benefit")}: ${s.benefit[lang]}`,
        `\n✔️ ${L(lang, "தகுதி", "Eligibility", "Eligibility")}: ${s.eligibility[lang]}`,
        `\n📄 ${L(lang, "தேவையான ஆவணங்கள்", "Thevaiyana documents", "Documents needed")}:\n${checklist(lang, s.docs, r.have)}`,
        `\n🪜 ${L(lang, "எப்படி விண்ணப்பிப்பது", "Eppadi apply panradhu", "How to apply")}:\n${s.steps[lang]}`,
        L(lang, "\n📷 ஆவணப் புகைப்படம் அனுப்புங்க, நான் சரிபார்க்கிறேன்.", "\n📷 Document photo anupunga, naan verify panren.", "\n📷 Send document photos and I'll verify them."),
      ].join("\n");
    }
    case "docguide": {
      const g = r.guide;
      return [
        `🗂️ *${g.title[lang]}* — ${L(lang, "எடுத்துட்டு போக வேண்டியவை", "eduthutu poga vendiyadhu", "what to carry")}:`,
        "\n" + g.docs.map((d) => `• ${DOC_NAMES[d][lang]}`).join("\n"),
        g.extra[lang],
        `\n💡 ${g.tips[lang]}`,
      ].join("\n");
    }
    case "docReceived": {
      if (!r.doc)
        return L(lang,
          "📷 புகைப்படம் கிடைச்சது, ஆனா எந்த ஆவணம்னு தெளிவா தெரியல. ரேஷன் கார்டு, வருமானச் சான்று, பட்டா, பாஸ்புக் — தெளிவான போட்டோ மீண்டும் அனுப்புங்க.",
          "📷 Photo kidaichadhu, aana endha document-nu clear-a theriyala. Ration card, income certificate, patta, passbook — clear photo thirumba anupunga.",
          "📷 Got the photo but couldn't identify the document. Please resend a clear photo of a ration card, income certificate, patta or passbook.");
      let out = L(lang, `✅ சரிபார்க்கப்பட்டது: *${DOC_NAMES[r.doc].ta}* — பெயர், தேதி தெளிவா இருக்கு.`, `✅ Verified: *${DOC_NAMES[r.doc].tl}* — per, date clear-a irukku.`, `✅ Verified: *${DOC_NAMES[r.doc].en}* — name and date are readable.`);
      if (r.scheme) {
        const missing = r.scheme.docs.filter((d) => !r.have.includes(d));
        out += `\n\n${r.scheme.name[lang]}:\n${checklist(lang, r.scheme.docs, r.have)}`;
        out += missing.length
          ? L(lang, `\n\nஇன்னும் ${missing.length} ஆவணம் தேவை.`, `\n\nInnum ${missing.length} document venum.`, `\n\n${missing.length} more document(s) needed.`)
          : L(lang, "\n\n🎉 எல்லா ஆவணமும் தயார்! இப்போ விண்ணப்பிக்கலாம்.", "\n\n🎉 Ella documents-um ready! Ippo apply pannalam.", "\n\n🎉 All documents ready! You can apply now.");
      } else out += L(lang, "\n\nஎந்த திட்டத்துக்கு வேணும்னு சொல்லுங்க.", "\n\nEndha scheme-ku venum-nu sollunga.", "\n\nTell me which scheme this is for.");
      return out;
    }
    case "verify":
      if (!r.scheme) return L(lang, "முதல்ல ஒரு திட்டம் பெயர் சொல்லுங்க.", "Mudhalla oru scheme per sollunga.", "First tell me a scheme name.");
      return `${r.scheme.name[lang]}:\n${checklist(lang, r.scheme.docs, r.have)}`;
    case "unknown":
      return L(lang,
        "மன்னிக்கவும், உங்க கேள்வி சரியா புரியல 🙏 கொஞ்சம் மீண்டும் கேளுங்க.\nஉதாரணம்: \"வீடு கட்ட உதவி\", \"பயிர் காப்பீடு\", \"வங்கிக் கடனுக்கு என்ன ஆவணம்?\"",
        "Mannikavum, unga kelvi sariya puriyala 🙏 Konjam thirumba kelunga.\nExample: \"veedu katta udhavi\", \"payir kaapeedu\", \"bank loan-ku enna documents?\"",
        "Sorry, I didn't understand 🙏 Please ask again.\nExample: \"housing help\", \"crop insurance\", \"documents for bank loan?\"");
  }
}

export const SUGGESTIONS: Record<Lang, string[]> = {
  ta: ["வீடு கட்ட உதவி", "பிஎம் கிசான்", "வங்கிக் கடனுக்கு என்ன ஆவணம்?", "என்ன திட்டங்கள் இருக்கு?"],
  tl: ["Veedu katta udhavi", "PM Kisan", "Bank loan ku enna documents venum?", "Enna schemes irukku?"],
  en: ["Housing help", "PM Kisan", "Documents for bank loan?", "What schemes are there?"],
};

export const UI: Record<Lang, Record<"online"|"typing"|"placeholder"|"docs"|"docsHint"|"upload"|"rec"|"listening"|"agents", string>> = {
  ta: { online: "ஆன்லைன்", typing: "டைப் செய்கிறது…", placeholder: "செய்தி", docs: "சோதனை ஆவணங்கள்", docsHint: "தட்டினால் புகைப்படமாக அனுப்பப்படும்", upload: "உங்க புகைப்படம் பதிவேற்று", rec: "பதிவு செய்கிறது…", listening: "கேட்டது", agents: "AI முகவர்கள்" },
  tl: { online: "online", typing: "typing…", placeholder: "Message", docs: "Test documents", docsHint: "Tap panna photo-va anupum", upload: "Unga photo upload", rec: "Recording…", listening: "Ketadhu", agents: "AI agents" },
  en: { online: "online", typing: "typing…", placeholder: "Message", docs: "Test documents", docsHint: "Tap to send as a photo", upload: "Upload your own photo", rec: "Recording…", listening: "Heard", agents: "AI agents" },
};
