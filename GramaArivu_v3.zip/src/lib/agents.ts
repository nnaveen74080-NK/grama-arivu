// GramaArivu prototype: 3-agent pipeline running fully in the browser.
// Agent 1 = intent detection, Agent 2 = scheme/doc matcher (local DB), Agent 3 = compliance + document verifier.

export type Lang = "ta" | "tl" | "en";
export type T = Record<Lang, string>;

export type DocType = "ration" | "income" | "patta" | "passbook" | "community" | "photo" | "aadhaar";

export const DOC_NAMES: Record<DocType, T> = {
  aadhaar: { ta: "ஆதார் அட்டை", tl: "Aadhaar card", en: "Aadhaar card" },
  ration: { ta: "குடும்ப அட்டை (ரேஷன்)", tl: "Ration card", en: "Ration card" },
  income: { ta: "வருமானச் சான்றிதழ்", tl: "Income certificate", en: "Income certificate" },
  patta: { ta: "பட்டா / சிட்டா (நில ஆவணம்)", tl: "Patta / Chitta (land document)", en: "Patta / Chitta (land record)" },
  passbook: { ta: "வங்கி பாஸ்புக்", tl: "Bank passbook", en: "Bank passbook" },
  community: { ta: "சாதிச் சான்றிதழ்", tl: "Community certificate", en: "Community certificate" },
  photo: { ta: "பாஸ்போர்ட் புகைப்படம்", tl: "Passport size photo", en: "Passport size photo" },
};

export type Scheme = {
  id: string;
  keywords: string[];
  name: T;
  benefit: T;
  eligibility: T;
  docs: DocType[];
  steps: T;
};

// "SQLite"-style local scheme table (prototype)
export const SCHEMES: Scheme[] = [
  {
    id: "pmkisan",
    keywords: ["kisan", "கிசான்", "pm kisan", "6000", "விவசாய உதவி", "farmer money", "vivasayi panam", "vivasaya udhavi"],
    name: { ta: "பிஎம் கிசான் (PM-KISAN)", tl: "PM-KISAN", en: "PM-KISAN" },
    benefit: { ta: "வருடத்துக்கு ₹6,000 — மூன்று தவணையா ₹2,000 உங்க வங்கிக் கணக்குல வரும்.", tl: "Varushathukku ₹6,000 — 3 thavanai-ya ₹2,000 unga bank account-la varum.", en: "₹6,000 per year, paid as three ₹2,000 instalments to your bank account." },
    eligibility: { ta: "சொந்த விவசாய நிலம் உள்ள விவசாயக் குடும்பம். அரசு ஊழியர், வருமான வரி கட்டுறவங்க தகுதி இல்லை.", tl: "Sondha vivasaya nilam irukra family. Govt employee, income tax kattravanga eligible illa.", en: "Farmer families owning cultivable land. Govt employees and income-tax payers are not eligible." },
    docs: ["aadhaar", "patta", "passbook"],
    steps: { ta: "1. அருகில் உள்ள இ-சேவை மையம் போங்க. 2. pmkisan.gov.in ல பதிவு செய்யுங்க. 3. VAO கிட்ட நில விவரம் சரிபார்ப்பாங்க. 4. e-KYC முடிச்சா பணம் வரும்.", tl: "1. Pakkathula irukra e-Sevai centre ponga. 2. pmkisan.gov.in la register pannunga. 3. VAO nila details verify pannuvaanga. 4. e-KYC mudicha panam varum.", en: "1. Visit the nearest e-Sevai centre. 2. Register on pmkisan.gov.in. 3. VAO verifies land details. 4. Complete e-KYC to receive payments." },
  },
  {
    id: "pmay",
    keywords: ["veedu", "வீடு", "house", "housing", "awas", "home loan", "veetu", "kudisai", "குடிசை"],
    name: { ta: "பிரதமர் வீட்டு வசதித் திட்டம் (PMAY-G)", tl: "PM Awas Yojana – Gramin", en: "PM Awas Yojana – Gramin (PMAY-G)" },
    benefit: { ta: "கிராமத்துல புது வீடு கட்ட ₹1.2 லட்சம் வரை உதவித் தொகை.", tl: "Gramathula pudhu veedu katta ₹1.2 lakh varai udhavi.", en: "Up to ₹1.2 lakh assistance to build a pucca house in rural areas." },
    eligibility: { ta: "சொந்த பக்கா வீடு இல்லாதவங்க, குடிசை / பழுதடைந்த வீட்டில் இருப்பவங்க.", tl: "Sondha pucca veedu illadhavanga, kudisai / odanja veetla irukravanga.", en: "Families without a pucca house, living in kutcha or dilapidated houses." },
    docs: ["aadhaar", "ration", "income", "passbook", "photo"],
    steps: { ta: "1. கிராம பஞ்சாயத்து அலுவலகத்துல பெயர் கொடுங்க. 2. ஆவணங்கள் சமர்ப்பிங்க. 3. அதிகாரி நேரில் வந்து பார்ப்பாங்க. 4. தவணையா பணம் வரும்.", tl: "1. Grama panchayat office-la per kudunga. 2. Documents submit pannunga. 3. Officer nerla vandhu paapaanga. 4. Thavanai-ya panam varum.", en: "1. Register at the Gram Panchayat office. 2. Submit documents. 3. Officer does site inspection. 4. Funds released in instalments." },
  },
  {
    id: "kcc",
    keywords: ["kcc", "kisan credit", "crop loan", "payir kadan", "பயிர் கடன்", "விவசாய கடன்", "vivasaya kadan", "agri loan"],
    name: { ta: "கிசான் கிரெடிட் கார்டு (KCC)", tl: "Kisan Credit Card (KCC)", en: "Kisan Credit Card (KCC)" },
    benefit: { ta: "குறைந்த வட்டியில் (4% வரை) ₹3 லட்சம் வரை பயிர்க் கடன்.", tl: "Kammi vatti-la (4% varai) ₹3 lakh varai payir kadan.", en: "Crop loans up to ₹3 lakh at concessional interest (as low as 4%)." },
    eligibility: { ta: "விவசாயிகள், குத்தகை விவசாயிகள், மீனவர்கள், கால்நடை வளர்ப்பவர்கள்.", tl: "Vivasayigal, kuthagai vivasayigal, meenavargal, kaalnadai valarpavargal.", en: "Farmers, tenant farmers, fishers and livestock rearers." },
    docs: ["aadhaar", "patta", "passbook", "photo"],
    steps: { ta: "1. உங்க வங்கிக் கிளைக்கு போங்க. 2. KCC விண்ணப்பம் நிரப்புங்க. 3. நில ஆவணம் கொடுங்க. 4. 2 வாரத்துல கார்டு கிடைக்கும்.", tl: "1. Unga bank branch-ku ponga. 2. KCC form fill pannunga. 3. Nila document kudunga. 4. 2 vaarathula card kidaikkum.", en: "1. Visit your bank branch. 2. Fill the KCC form. 3. Submit land records. 4. Card issued in ~2 weeks." },
  },
  {
    id: "fasal",
    keywords: ["insurance", "bima", "காப்பீடு", "kaapeedu", "crop insurance", "payir kaapeedu", "மழை", "flood", "vellam"],
    name: { ta: "பயிர் காப்பீட்டுத் திட்டம் (PMFBY)", tl: "PM Fasal Bima Yojana", en: "PM Fasal Bima Yojana (crop insurance)" },
    benefit: { ta: "மழை, வெள்ளம், வறட்சியால் பயிர் சேதமானா இழப்பீடு. பிரீமியம் 1.5%–2% தான்.", tl: "Mazhai, vellam, varatchi-naala payir damage aana compensation. Premium 1.5%–2% dhaan.", en: "Compensation for crop loss due to rain, flood or drought. Premium only 1.5–2%." },
    eligibility: { ta: "அறிவிக்கப்பட்ட பயிர் பயிரிடும் அனைத்து விவசாயிகளும்.", tl: "Notify panna payir podra ella vivasayigalum.", en: "All farmers growing notified crops in notified areas." },
    docs: ["aadhaar", "patta", "passbook"],
    steps: { ta: "1. விதைப்பு முடிந்த 2 வாரத்துக்குள் வங்கி / இ-சேவையில் பதிவு. 2. பிரீமியம் கட்டுங்க. 3. சேதம் ஆனா 72 மணி நேரத்துக்குள் தெரிவிங்க.", tl: "1. Vidhaippu mudinja 2 vaarathukulla bank / e-Sevai la register. 2. Premium kattunga. 3. Damage aana 72 mani nerathukulla sollunga.", en: "1. Enrol within 2 weeks of sowing at bank/e-Sevai. 2. Pay premium. 3. Report damage within 72 hours." },
  },
  {
    id: "mudra",
    keywords: ["mudra", "முத்ரா", "business loan", "tholil", "தொழில்", "kadai", "கடை", "self employ", "small business"],
    name: { ta: "முத்ரா கடன் (PMMY)", tl: "Mudra Loan", en: "PM Mudra Yojana" },
    benefit: { ta: "சிறு தொழில் தொடங்க ₹50,000 முதல் ₹10 லட்சம் வரை அடமானம் இல்லாத கடன்.", tl: "Siru thozhil start panna ₹50,000 – ₹10 lakh varai collateral illadha kadan.", en: "Collateral-free loans from ₹50,000 to ₹10 lakh for small businesses." },
    eligibility: { ta: "18 வயதுக்கு மேல், விவசாயம் இல்லாத சிறு தொழில் / கடை நடத்துறவங்க.", tl: "18 vayasukku mela, non-farm siru thozhil / kadai nadathravanga.", en: "Age 18+, running or starting a non-farm micro business." },
    docs: ["aadhaar", "passbook", "photo", "income"],
    steps: { ta: "1. எந்த வங்கியிலும் விண்ணப்பிக்கலாம். 2. தொழில் திட்டம் சொல்லுங்க. 3. ஆவணங்கள் கொடுங்க.", tl: "1. Endha bank-layum apply pannalam. 2. Business plan sollunga. 3. Documents kudunga.", en: "1. Apply at any bank. 2. Share a simple business plan. 3. Submit documents." },
  },
  {
    id: "ujjwala",
    keywords: ["gas", "கேஸ்", "ujjwala", "cylinder", "சிலிண்டர்", "lpg", "aduppu", "அடுப்பு"],
    name: { ta: "உஜ்வாலா இலவச கேஸ் இணைப்பு", tl: "Ujjwala free gas connection", en: "PM Ujjwala Yojana" },
    benefit: { ta: "இலவச LPG இணைப்பு + முதல் சிலிண்டர் + அடுப்பு.", tl: "Free LPG connection + first cylinder + aduppu.", en: "Free LPG connection, first refill and stove." },
    eligibility: { ta: "வறுமைக்கோட்டுக்கு கீழ் உள்ள குடும்பப் பெண்கள், வீட்டில் கேஸ் இணைப்பு இல்லாதவர்கள்.", tl: "BPL family pengal, veetla gas connection illadhavanga.", en: "Women from BPL households without an existing LPG connection." },
    docs: ["aadhaar", "ration", "passbook", "photo"],
    steps: { ta: "1. அருகில் உள்ள கேஸ் ஏஜென்சிக்கு போங்க. 2. KYC படிவம் கொடுங்க.", tl: "1. Pakkathula irukra gas agency-ku ponga. 2. KYC form kudunga.", en: "1. Visit the nearest LPG distributor. 2. Submit the KYC form." },
  },
  {
    id: "health",
    keywords: ["health", "hospital", "maruthuvam", "மருத்துவ", "ayushman", "aayushman", "காப்பீட்டு அட்டை", "treatment", "operation"],
    name: { ta: "முதலமைச்சர் விரிவான மருத்துவக் காப்பீடு (CMCHIS) + ஆயுஷ்மான் பாரத்", tl: "CM Health Insurance + Ayushman Bharat", en: "CMCHIS + Ayushman Bharat health cover" },
    benefit: { ta: "குடும்பத்துக்கு வருடத்துக்கு ₹5 லட்சம் வரை இலவச சிகிச்சை.", tl: "Family-ku varushathukku ₹5 lakh varai free treatment.", en: "Free treatment up to ₹5 lakh per family per year." },
    eligibility: { ta: "ஆண்டு குடும்ப வருமானம் ₹1.2 லட்சத்துக்கு கீழ்.", tl: "Varusha family income ₹1.2 lakh-ku keezha.", en: "Annual family income below ₹1.2 lakh." },
    docs: ["ration", "income", "aadhaar"],
    steps: { ta: "1. மாவட்ட காப்பீட்டு கியாஸ்க்கில் பதிவு. 2. புகைப்படம் எடுப்பாங்க. 3. அட்டை உடனே கிடைக்கும்.", tl: "1. District insurance kiosk-la register. 2. Photo edupaanga. 3. Card udane kidaikkum.", en: "1. Register at the district insurance kiosk. 2. Photo taken on site. 3. Card issued immediately." },
  },
  {
    id: "urimai",
    keywords: ["magalir", "மகளிர்", "urimai", "உரிமை", "1000", "women", "pengal", "பெண்கள்"],
    name: { ta: "கலைஞர் மகளிர் உரிமைத் தொகை", tl: "Magalir Urimai Thogai", en: "Kalaignar Magalir Urimai Thogai" },
    benefit: { ta: "குடும்பத் தலைவிக்கு மாதம் ₹1,000.", tl: "Kudumba thalaivi-ku maasam ₹1,000.", en: "₹1,000 per month to the woman head of family." },
    eligibility: { ta: "21 வயதுக்கு மேல், ஆண்டு குடும்ப வருமானம் ₹2.5 லட்சத்துக்கு கீழ், 5 ஏக்கருக்கு கீழ் நிலம்.", tl: "21 vayasukku mela, family income ₹2.5 lakh-ku keezha, 5 acre-ku keezha nilam.", en: "Women 21+, family income under ₹2.5 lakh, land under 5 acres." },
    docs: ["ration", "aadhaar", "passbook"],
    steps: { ta: "1. ரேஷன் கடை முகாமில் விண்ணப்பம். 2. சரிபார்ப்பு முடிந்ததும் வங்கியில் பணம்.", tl: "1. Ration kadai camp-la apply. 2. Verify aana bank-la panam.", en: "1. Apply at the ration shop camp. 2. Money credited after verification." },
  },
  {
    id: "pension",
    keywords: ["pension", "ஓய்வூதியம்", "oyvoodhiyam", "old age", "vayasaana", "முதியோர்", "mudhiyor", "widow", "vidhavai", "விதவை"],
    name: { ta: "முதியோர் / விதவை ஓய்வூதியம்", tl: "Old age / Widow pension", en: "Old age / Widow pension (IGNOAPS)" },
    benefit: { ta: "மாதம் ₹1,200 ஓய்வூதியம்.", tl: "Maasam ₹1,200 pension.", en: "₹1,200 monthly pension." },
    eligibility: { ta: "60 வயதுக்கு மேல் (அல்லது விதவை), வேறு வருமானம் / ஆதரவு இல்லாதவர்கள்.", tl: "60 vayasukku mela (or widow), vera varumanam / support illadhavanga.", en: "Age 60+ (or widows) without other income or support." },
    docs: ["aadhaar", "ration", "income", "passbook", "photo"],
    steps: { ta: "1. தாலுகா அலுவலகம் / இ-சேவையில் விண்ணப்பம். 2. VAO சரிபார்ப்பு. 3. மாதம் தோறும் பணம்.", tl: "1. Taluk office / e-Sevai la apply. 2. VAO verify. 3. Maasam maasam panam.", en: "1. Apply at Taluk office / e-Sevai. 2. VAO verification. 3. Monthly payment." },
  },
  {
    id: "scholarship",
    keywords: ["scholarship", "உதவித்தொகை", "padippu", "படிப்பு", "student", "school", "college", "kalvi", "கல்வி", "pudhumai"],
    name: { ta: "கல்வி உதவித்தொகை (புதுமைப் பெண் / போஸ்ட்-மெட்ரிக்)", tl: "Scholarship (Pudhumai Penn / Post-matric)", en: "Education scholarships (Pudhumai Penn / Post-matric)" },
    benefit: { ta: "கல்லூரி மாணவிகளுக்கு மாதம் ₹1,000; SC/ST/BC மாணவர்களுக்கு கட்டண உதவி.", tl: "College maanavigalukku maasam ₹1,000; SC/ST/BC students-ku fees udhavi.", en: "₹1,000/month for girl students in college; fee support for SC/ST/BC students." },
    eligibility: { ta: "அரசுப் பள்ளியில் 6–12 படித்து கல்லூரி சேர்ந்தவர்கள் / வருமான வரம்புக்குள் உள்ள குடும்பம்.", tl: "Govt school-la 6–12 padichu college serndhavanga / income limit-kulla family.", en: "Studied classes 6–12 in govt school, or family within income limit." },
    docs: ["aadhaar", "community", "income", "passbook"],
    steps: { ta: "1. கல்லூரி மூலமாக இணையதளத்தில் விண்ணப்பம். 2. சான்றிதழ்கள் பதிவேற்றம்.", tl: "1. College moolama website-la apply. 2. Certificates upload.", en: "1. Apply online through your college. 2. Upload certificates." },
  },
];

// Document-guide table: "what documents do I need for X"
export type DocGuide = { id: string; keywords: string[]; title: T; docs: DocType[]; extra: T; tips: T };
export const DOC_GUIDES: DocGuide[] = [
  {
    id: "bankloan",
    keywords: ["bank loan", "loan", "kadan", "கடன்", "வங்கி", "personal loan", "gold loan", "nagai"],
    title: { ta: "வங்கிக் கடன் விண்ணப்பம்", tl: "Bank loan apply panna", en: "Applying for a bank loan" },
    docs: ["aadhaar", "passbook", "income", "photo", "ration"],
    extra: { ta: "• PAN கார்டு\n• கடைசி 6 மாத வங்கி ஸ்டேட்மெண்ட்\n• விவசாயக் கடனுக்கு: பட்டா / சிட்டா / அடங்கல்\n• நகைக் கடனுக்கு: நகை + ஆதார் மட்டும் போதும்", tl: "• PAN card\n• Last 6 maasa bank statement\n• Vivasaya kadan-ku: Patta / Chitta / Adangal\n• Nagai kadan-ku: Nagai + Aadhaar mattum podhum", en: "• PAN card\n• Last 6 months bank statement\n• For farm loans: Patta / Chitta / Adangal\n• For gold loans: just the gold + ID" },
    tips: { ta: "எல்லா ஆவணத்துக்கும் 2 நகல் (xerox) எடுத்துட்டு போங்க. அசல் ஆவணத்தையும் கூட வச்சுக்கோங்க.", tl: "Ella document-kum 2 xerox eduthutu ponga. Original-um kooda vechukonga.", en: "Carry 2 photocopies of every document along with the originals." },
  },
  {
    id: "rationapply",
    keywords: ["new ration", "ration card apply", "pudhu ration", "புது ரேஷன்", "ration card venum", "ration card eppadi"],
    title: { ta: "புதிய குடும்ப அட்டை", tl: "Pudhu ration card", en: "New ration card" },
    docs: ["aadhaar", "photo", "passbook"],
    extra: { ta: "• முகவரிச் சான்று (மின் கட்டண ரசீது / வாடகை ஒப்பந்தம்)\n• பழைய அட்டையில் இருந்து பெயர் நீக்கச் சான்று", tl: "• Address proof (EB bill / rental agreement)\n• Pazhaya card-la irundhu per neekkam certificate", en: "• Address proof (EB bill / rent agreement)\n• Name-deletion certificate from earlier card" },
    tips: { ta: "tnpds.gov.in ல ஆன்லைனாவும் விண்ணப்பிக்கலாம்.", tl: "tnpds.gov.in la online-aavum apply pannalam.", en: "You can also apply online at tnpds.gov.in." },
  },
  {
    id: "incomeapply",
    keywords: ["income certificate", "varumana", "வருமானச் சான்று", "வருமான சான்றிதழ்", "income cert"],
    title: { ta: "வருமானச் சான்றிதழ் பெற", tl: "Income certificate vaanga", en: "Getting an income certificate" },
    docs: ["aadhaar", "ration", "photo"],
    extra: { ta: "• சம்பளச் சான்று அல்லது சுய அறிவிப்புப் படிவம்\n• VAO பரிந்துரை", tl: "• Salary proof or self-declaration form\n• VAO recommendation", en: "• Salary proof or self-declaration\n• VAO recommendation" },
    tips: { ta: "இ-சேவை மையத்துல ₹60 கட்டணம். 7–15 நாள்ல கிடைக்கும்.", tl: "e-Sevai la ₹60 fees. 7–15 naal-la kidaikkum.", en: "₹60 fee at e-Sevai; issued in 7–15 days." },
  },
  {
    id: "pattaapply",
    keywords: ["patta", "பட்டா", "chitta", "land transfer", "nila", "நிலம்"],
    title: { ta: "பட்டா மாற்றம் / பெற", tl: "Patta maatram / vaanga", en: "Patta transfer / issue" },
    docs: ["aadhaar", "photo"],
    extra: { ta: "• கிரையப் பத்திரம் (sale deed)\n• வில்லங்கச் சான்று (EC)\n• முந்தைய பட்டா நகல்", tl: "• Sale deed\n• Encumbrance certificate (EC)\n• Munnadi patta xerox", en: "• Sale deed\n• Encumbrance certificate (EC)\n• Previous patta copy" },
    tips: { ta: "eservices.tn.gov.in ல பட்டா நிலையை பார்க்கலாம்.", tl: "eservices.tn.gov.in la patta status paakalam.", en: "Check patta status on eservices.tn.gov.in." },
  },
];

// ---------------- Agent 1: Listener & Intent ----------------
export type Intent =
  | { type: "greet" }
  | { type: "scheme"; scheme: Scheme }
  | { type: "docguide"; guide: DocGuide }
  | { type: "list" }
  | { type: "verify" }
  | { type: "unknown" };

const norm = (s: string) => s.toLowerCase().replace(/\s+/g, " ").trim();

export function agentIntent(text: string): Intent {
  const t = norm(text);
  if (!t) return { type: "unknown" };
  if (/^(hi|hello|hai|vanakkam|வணக்கம்|hey|namaste)\b/.test(t)) return { type: "greet" };
  if (/(all scheme|scheme list|enna scheme|என்ன திட்ட|thittam|திட்டங்கள்|schemes)/.test(t)) return { type: "list" };
  if (/(verify|check my doc|sari paaru|சரிபார்)/.test(t)) return { type: "verify" };
  const askingDocs = /(document|ஆவண|aavanam|enna enna|என்ன என்ன|eduthutu|எடுத்துட்டு|what.*need|venum|வேணும்|தேவை)/.test(t);
  // Doc guide wins when user asks about documents for a generic thing like a bank loan
  const guide = DOC_GUIDES.find((g) => g.keywords.some((k) => t.includes(k)));
  const scheme = SCHEMES.find((s) => s.keywords.some((k) => t.includes(k)));
  if (scheme && (!guide || !askingDocs || scheme.id === "kcc" && /kcc|kisan|payir|பயிர்/.test(t))) return { type: "scheme", scheme };
  if (guide) return { type: "docguide", guide };
  if (scheme) return { type: "scheme", scheme };
  return { type: "unknown" };
}

// Detect document type from filename (prototype "vision")
export function agentDetectDoc(name: string): DocType | null {
  const n = name.toLowerCase();
  if (/ration|kudumba|family/.test(n)) return "ration";
  if (/income|varumana/.test(n)) return "income";
  if (/patta|chitta|land/.test(n)) return "patta";
  if (/pass ?book|bank/.test(n)) return "passbook";
  if (/community|caste|jathi/.test(n)) return "community";
  if (/aadhaar|aadhar|adhar/.test(n)) return "aadhaar";
  if (/photo|selfie|passport/.test(n)) return "photo";
  return null;
}
