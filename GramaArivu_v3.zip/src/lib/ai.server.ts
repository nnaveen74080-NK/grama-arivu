const BASE = "https://ai.gateway.lovable.dev";
const CHAT_MODEL = "openai/gpt-6-astra";
const TTS_MODEL = "google/gemini-3.1-flash-tts-preview";
const STT_MODEL = "openai/gpt-transcribe";

export class AiError extends Error {
  constructor(public status: number, message: string) {
    super(message);
  }
}

function key() {
  const k = process.env["LOVABLE_API_KEY"];
  if (!k) throw new AiError(500, "AI key missing");
  return k;
}

export async function transcribe(audio: Blob, filename: string) {
  const fd = new FormData();
  fd.append("file", audio, filename);
  fd.append("model", STT_MODEL);
  fd.append("languages", "ta");
  fd.append("languages", "en");
  const r = await fetch(`${BASE}/v1/audio/transcriptions`, {
    method: "POST",
    headers: { Authorization: `Bearer ${key()}` },
    body: fd,
  });
  if (!r.ok) throw new AiError(r.status, `Transcription failed [${r.status}]: ${await r.text()}`);
  const j = (await r.json()) as { text?: string };
  return (j.text ?? "").trim();
}

const SYSTEM = (lang: string) => `You are GramaArivu, a friendly assistant for rural people in Tamil Nadu, India (farmers, villagers).
You explain Central and Tamil Nadu government schemes, loans (bank loan, crop loan, KCC, Mudra, housing), subsidies, pensions, scholarships, certificates — eligibility, benefits, exact list of documents needed, and step-by-step how/where to apply (VAO office, Taluk office, e-Sevai centre, bank, websites).
Answer ANY question the user asks; if unclear, make a sensible guess and answer, then ask one short follow-up. Never say you did not understand.
When the user sends a document photo: identify what document it is (Aadhaar, ration card, patta, chitta, income/community/nativity certificate, bank passbook, voter ID, PAN, etc.), check if it looks clear, complete and readable, mention any visible problems (blurry, cut off, expired, name mismatch), and say which schemes it is useful for and what other documents are still needed. Do not repeat full ID numbers.
Reply language: ${lang === "en" ? "simple English" : lang === "tl" ? "Tanglish (Tamil written in English letters)" : "simple, clear spoken Tamil in Tamil script"}.
Keep replies short and spoken-friendly (max ~120 words), use short numbered points, no markdown symbols like * or #, no emojis. Add a one-line note to verify on the official site when giving amounts.`;

export async function answer(
  lang: string,
  history: { role: "user" | "assistant"; text: string }[],
  text: string,
  image?: string,
) {
  const content: Record<string, unknown>[] = [{ type: "input_text", text: text || "Please check this document." }];
  if (image) content.push({ type: "input_image", image_url: image });
  const input = [
    { role: "system", content: SYSTEM(lang) },
    ...history.slice(-8).map((h) =>
      h.role === "user"
        ? { role: "user", content: [{ type: "input_text", text: h.text }] }
        : { role: "assistant", content: [{ type: "output_text", text: h.text }] },
    ),
    { role: "user", content },
  ];
  const r = await fetch(`${BASE}/v1/responses`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "Lovable-API-Key": key(), "X-Lovable-AIG-SDK": "fetch" },
    body: JSON.stringify({ model: CHAT_MODEL, input, stream: true, store: false, reasoning: { effort: "low", summary: "auto" }, include: ["reasoning.encrypted_content"] }),
  });
  if (!r.ok || !r.body) throw new AiError(r.status, `AI failed [${r.status}]: ${await r.text()}`);
  const reader = r.body.getReader();
  const dec = new TextDecoder();
  let buf = "", out = "";
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    let i;
    while ((i = buf.indexOf("\n")) >= 0) {
      const line = buf.slice(0, i).trim();
      buf = buf.slice(i + 1);
      if (!line.startsWith("data:")) continue;
      const d = line.slice(5).trim();
      if (!d || d === "[DONE]") continue;
      try {
        const ev = JSON.parse(d);
        if (ev.type === "response.output_text.delta") out += ev.delta;
        else if (ev.type === "error" || ev.type === "response.failed")
          throw new AiError(502, ev.error?.message ?? ev.response?.error?.message ?? "AI error");
      } catch (e) {
        if (e instanceof AiError) throw e;
      }
    }
  }
  out = out.trim();
  if (!out) throw new AiError(502, "AI returned an empty answer");
  return out;
}

export async function speech(text: string) {
  const r = await fetch(`${BASE}/v1/audio/speech`, {
    method: "POST",
    headers: { Authorization: `Bearer ${key()}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model: TTS_MODEL,
      contents: [{ role: "user", parts: [{ text: `Read this aloud clearly, slowly and warmly, in a natural Tamil Nadu accent:\n${text}` }] }],
      generationConfig: { responseModalities: ["AUDIO"], speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: "Kore" } } } },
      stream_format: "audio",
    }),
  });
  if (!r.ok) throw new AiError(r.status, `Speech failed [${r.status}]: ${await r.text()}`);
  const bytes = new Uint8Array(await r.arrayBuffer());
  let bin = "";
  for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return `data:${r.headers.get("Content-Type") ?? "audio/wav"};base64,${btoa(bin)}`;
}
